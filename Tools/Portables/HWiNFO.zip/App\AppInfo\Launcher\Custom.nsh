Var strCustomComputerName

${SegmentFile}

${SegmentInit}
	${registry::Read} "HKLM\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName" "ComputerName" $strCustomComputerName $0

	${If} $Bits == 32
		Rename "$EXEDIR\Data\HWiNFO64.ini" "$EXEDIR\Data\HWiNFO32.ini"
	${Else}
		Rename "$EXEDIR\Data\HWiNFO32.ini" "$EXEDIR\Data\HWiNFO64.ini"
	${EndIf}
!macroend

${SegmentPrePrimary}
	${If} ${FileExists} "$EXEDIR\Data\settings\HWiNFO32-$strCustomComputerName.reg"
		${If} ${FileExists} "$EXEDIR\Data\settings\HWiNFO32.reg"
			Rename "$EXEDIR\Data\settings\HWiNFO32.reg" "$EXEDIR\Data\settings\HWiNFO32-Unknown.reg"
		${EndIf}
		Rename "$EXEDIR\Data\settings\HWiNFO32-$strCustomComputerName.reg" "$EXEDIR\Data\settings\HWiNFO32.reg"
	${EndIf}
	${If} ${FileExists} "$EXEDIR\Data\settings\HWiNFO64-$strCustomComputerName.reg"
		${If} ${FileExists} "$EXEDIR\Data\settings\HWiNFO64.reg"
			Rename "$EXEDIR\Data\settings\HWiNFO64.reg" "$EXEDIR\Data\settings\HWiNFO64-Unknown.reg"
		${EndIf}
		Rename "$EXEDIR\Data\settings\HWiNFO64-$strCustomComputerName.reg" "$EXEDIR\Data\settings\HWiNFO64.reg"
	${EndIf}
!macroend


${SegmentPostPrimary}
	Delete "$EXEDIR\Data\settings\HWiNFO32-$strCustomComputerName.reg"
	Rename "$EXEDIR\Data\settings\HWiNFO32.reg" "$EXEDIR\Data\settings\HWiNFO32-$strCustomComputerName.reg"
	Delete "$EXEDIR\Data\settings\HWiNFO64-$strCustomComputerName.reg"
	Rename "$EXEDIR\Data\settings\HWiNFO64.reg" "$EXEDIR\Data\settings\HWiNFO64-$strCustomComputerName.reg"
!macroend
